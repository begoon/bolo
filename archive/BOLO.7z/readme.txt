BOLO
by Elvyn Software, 1982

Unofficial IBM PC port of original game for Apple II by MrRm, 1993.
It's for MS-DOS, but runs in Windows XP too.


You have to destroy 6 enemy bases. Find them in the maze with your radar and
hit the center.


Keys:

cursor keys - move tank
1, 2 - turn your gun
3 - fire
ESC - exit game
